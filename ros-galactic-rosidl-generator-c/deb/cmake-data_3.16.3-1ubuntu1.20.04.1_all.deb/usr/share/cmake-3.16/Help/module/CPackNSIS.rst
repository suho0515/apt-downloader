CPackNSIS
---------

The documentation for the CPack NSIS generator has moved here: :cpack_gen:`CPack NSIS Generator`
