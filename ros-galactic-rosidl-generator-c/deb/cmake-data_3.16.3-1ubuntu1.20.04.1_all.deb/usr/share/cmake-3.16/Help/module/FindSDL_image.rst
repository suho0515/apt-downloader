.. cmake-module:: ../../Modules/FindSDL_image.cmake
