.. cmake-module:: ../../Modules/FindLibXslt.cmake
